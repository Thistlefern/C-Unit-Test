Welcome to my Math for Games assessment.

To be perfectly honest, I still understand very little from this subject.

I was able to get the bullet to fire on my own, but the rest was copied
verbatum from the tutorials, or was achieved through help from Terry.

The bullet doesn't fire directly from the turret, it's off center.
It doesn't even spawn when you hit space, it just always exists and is
hidden. It doesn't have collision tests, despite my efforts to figure
out how to do so in RayLib.

I also didn't finish the UnitTest tests. I tried for hours to figure out
how to make the Color tests work based on the tutorial, but like much
of this subject, all of the words bounced off of my brain, and nothing
stuck.

I'm not pleased with how this turned out, but frankly, I'm so done being
so in the dark with this subject that I'm ready to throw in the towel.
I'd rather not throw in the towel with coding all together, so I'm trying
to keep my cool and not cry as I write this.

I understand the math, for the most part. I DO NOT understand Raylib.
And I wouldn't have been able to build even this flimsy excuse for a game
without the tutorials telling me what to do the whole time.

Nothing has stuck with me during this subject. I'm looking forward to
(hopefully) getting back to understanding class material.

This README was supposed to tell you how to compile the game, I know.
But I also know, in my cynical and frustrated brain, that you know how to
compile a VS and Raylib program. So instead, I wrote this confession.

Sincerely,
Josie, a very anxious and self-depricating teacher's pet